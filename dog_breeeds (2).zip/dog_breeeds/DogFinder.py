from turtle import shape
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from matplotlib import pyplot as plt
import matplotlib.image as mpimg

model = keras.models.load_model('C:/Fall_ILC/dog_breeeds/BaseModel')
print(model.summary())
def generate_images(file):
    img_path = 'C:/Fall_ILC/dog_breeeds/train'
    img = mpimg.imread(img_path + file)
    img1 = img[0:128, 0:128]
    img2 = img[0:128, -128:]
    img3= img[-128:, 0:128]
    img4 = img[-128:,-128:]
    return [img, img1, img2, img3, img4]

img = generate_images('/Airedale/010.jpg')
plt.imshow(img[1])
plt.show()
print(img[1].shape)
prediction = model.predict(np.expand_dims(img[1], axis=0))
print(prediction.argmax())